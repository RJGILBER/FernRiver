<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="farmhouse_tiles" tilewidth="16" tileheight="16" tilecount="264" columns="12">
 <image source="farmhouse_tiles.png" width="192" height="352"/>
</tileset>
