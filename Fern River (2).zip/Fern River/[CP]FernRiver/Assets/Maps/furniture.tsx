<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="furniture" tilewidth="16" tileheight="16" tilecount="2976" columns="32">
 <image source="furniture.png" width="512" height="1488"/>
 <tile id="2080">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2081">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2084">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2085">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2086">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2090">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2091">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2092">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2096">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2097">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2098">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2102">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2103">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2104">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2108">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2109">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2208">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2209">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2212">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2213">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2214">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2218">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2219">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2220">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2224">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2225">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2226">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2230">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2231">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2232">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2236">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2237">
  <properties>
   <property name="Passable" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
