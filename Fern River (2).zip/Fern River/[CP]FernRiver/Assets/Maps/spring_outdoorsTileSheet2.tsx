<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="spring_outdoorsTileSheet2" tilewidth="16" tileheight="16" tilecount="1120" columns="16">
 <image source="spring_outdoorsTileSheet2.png" width="256" height="1120"/>
 <tile id="728">
  <animation>
   <frame tileid="728" duration="250"/>
   <frame tileid="732" duration="250"/>
  </animation>
 </tile>
 <tile id="729">
  <animation>
   <frame tileid="729" duration="250"/>
   <frame tileid="733" duration="250"/>
  </animation>
 </tile>
 <tile id="730">
  <animation>
   <frame tileid="730" duration="250"/>
   <frame tileid="734" duration="250"/>
  </animation>
 </tile>
 <tile id="744">
  <animation>
   <frame tileid="744" duration="250"/>
   <frame tileid="748" duration="250"/>
  </animation>
 </tile>
 <tile id="746">
  <animation>
   <frame tileid="746" duration="250"/>
   <frame tileid="750" duration="250"/>
  </animation>
 </tile>
 <tile id="760">
  <animation>
   <frame tileid="760" duration="250"/>
   <frame tileid="764" duration="250"/>
  </animation>
 </tile>
 <tile id="762">
  <animation>
   <frame tileid="762" duration="250"/>
   <frame tileid="766" duration="250"/>
  </animation>
 </tile>
 <tile id="792">
  <animation>
   <frame tileid="792" duration="250"/>
   <frame tileid="796" duration="250"/>
  </animation>
 </tile>
 <tile id="794">
  <animation>
   <frame tileid="794" duration="250"/>
   <frame tileid="798" duration="250"/>
  </animation>
 </tile>
 <tile id="808">
  <animation>
   <frame tileid="808" duration="250"/>
   <frame tileid="812" duration="250"/>
  </animation>
 </tile>
 <tile id="809">
  <animation>
   <frame tileid="809" duration="250"/>
   <frame tileid="813" duration="250"/>
  </animation>
 </tile>
 <tile id="810">
  <animation>
   <frame tileid="810" duration="250"/>
   <frame tileid="814" duration="250"/>
  </animation>
 </tile>
 <tile id="816">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="817">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="820">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="821">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="822">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="824">
  <animation>
   <frame tileid="824" duration="250"/>
   <frame tileid="828" duration="250"/>
  </animation>
 </tile>
 <tile id="825">
  <animation>
   <frame tileid="825" duration="250"/>
   <frame tileid="829" duration="250"/>
  </animation>
 </tile>
 <tile id="832">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="833">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="834">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="835">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="836">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="837">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="838">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="840">
  <animation>
   <frame tileid="840" duration="250"/>
   <frame tileid="844" duration="250"/>
  </animation>
 </tile>
 <tile id="841">
  <animation>
   <frame tileid="841" duration="250"/>
   <frame tileid="845" duration="250"/>
  </animation>
 </tile>
 <tile id="848">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="849">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="850">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="851">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="852">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="853">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="854">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="856">
  <animation>
   <frame tileid="856" duration="250"/>
   <frame tileid="860" duration="250"/>
  </animation>
 </tile>
 <tile id="857">
  <animation>
   <frame tileid="857" duration="250"/>
   <frame tileid="861" duration="250"/>
  </animation>
 </tile>
 <tile id="864">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="865">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="866">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="867">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="868">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="869">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="870">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="880">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="881">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="882">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="883">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="897">
  <animation>
   <frame tileid="897" duration="250"/>
   <frame tileid="929" duration="250"/>
  </animation>
 </tile>
 <tile id="898">
  <animation>
   <frame tileid="898" duration="250"/>
   <frame tileid="899" duration="250"/>
  </animation>
 </tile>
 <tile id="905">
  <animation>
   <frame tileid="905" duration="250"/>
   <frame tileid="937" duration="250"/>
  </animation>
 </tile>
 <tile id="912">
  <animation>
   <frame tileid="912" duration="250"/>
   <frame tileid="944" duration="250"/>
  </animation>
 </tile>
 <tile id="913">
  <animation>
   <frame tileid="913" duration="250"/>
   <frame tileid="945" duration="250"/>
  </animation>
 </tile>
 <tile id="914">
  <animation>
   <frame tileid="914" duration="250"/>
   <frame tileid="915" duration="250"/>
  </animation>
 </tile>
 <tile id="920">
  <animation>
   <frame tileid="920" duration="250"/>
   <frame tileid="952" duration="250"/>
  </animation>
 </tile>
 <tile id="921">
  <animation>
   <frame tileid="921" duration="250"/>
   <frame tileid="953" duration="250"/>
  </animation>
 </tile>
 <tile id="930">
  <animation>
   <frame tileid="930" duration="250"/>
   <frame tileid="931" duration="250"/>
  </animation>
 </tile>
 <tile id="938">
  <animation>
   <frame tileid="938" duration="250"/>
   <frame tileid="939" duration="250"/>
  </animation>
 </tile>
 <tile id="946">
  <animation>
   <frame tileid="946" duration="250"/>
   <frame tileid="947" duration="250"/>
  </animation>
 </tile>
 <tile id="960">
  <animation>
   <frame tileid="960" duration="250"/>
   <frame tileid="992" duration="250"/>
  </animation>
 </tile>
 <tile id="962">
  <animation>
   <frame tileid="962" duration="250"/>
   <frame tileid="963" duration="250"/>
  </animation>
 </tile>
 <tile id="968">
  <animation>
   <frame tileid="968" duration="250"/>
   <frame tileid="1000" duration="250"/>
  </animation>
 </tile>
 <tile id="976">
  <animation>
   <frame tileid="976" duration="250"/>
   <frame tileid="1008" duration="250"/>
  </animation>
 </tile>
 <tile id="977">
  <animation>
   <frame tileid="977" duration="250"/>
   <frame tileid="1009" duration="250"/>
  </animation>
 </tile>
 <tile id="978">
  <animation>
   <frame tileid="978" duration="250"/>
   <frame tileid="979" duration="250"/>
  </animation>
 </tile>
 <tile id="984">
  <animation>
   <frame tileid="984" duration="250"/>
   <frame tileid="1016" duration="250"/>
  </animation>
 </tile>
 <tile id="985">
  <animation>
   <frame tileid="985" duration="250"/>
   <frame tileid="1017" duration="250"/>
  </animation>
 </tile>
 <tile id="986">
  <animation>
   <frame tileid="986" duration="250"/>
   <frame tileid="987" duration="250"/>
  </animation>
 </tile>
 <tile id="1056">
  <animation>
   <frame tileid="1056" duration="250"/>
   <frame tileid="1057" duration="250"/>
  </animation>
 </tile>
 <tile id="1058">
  <animation>
   <frame tileid="1058" duration="250"/>
   <frame tileid="1059" duration="250"/>
  </animation>
 </tile>
 <tile id="1064">
  <animation>
   <frame tileid="1064" duration="250"/>
   <frame tileid="1065" duration="250"/>
  </animation>
 </tile>
 <tile id="1066">
  <animation>
   <frame tileid="1066" duration="250"/>
   <frame tileid="1067" duration="250"/>
  </animation>
 </tile>
</tileset>
