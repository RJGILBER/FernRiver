<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="spring_town" tilewidth="16" tileheight="16" tilecount="2304" columns="32">
 <image source="spring_town.png" width="512" height="1152"/>
</tileset>
