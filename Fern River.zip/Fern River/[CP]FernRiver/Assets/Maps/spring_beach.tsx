<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="spring_beach" tilewidth="16" tileheight="16" tilecount="527" columns="17">
 <image source="spring_beach.png" width="272" height="496"/>
 <tile id="0">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="75">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="89">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="90">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="91">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="92">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="93">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="107">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="108">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="109">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="110">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="124">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="125">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="127">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="129">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="130">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="131">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="141">
  <animation>
   <frame tileid="141" duration="250"/>
   <frame tileid="142" duration="250"/>
   <frame tileid="143" duration="250"/>
   <frame tileid="144" duration="250"/>
   <frame tileid="145" duration="250"/>
   <frame tileid="146" duration="250"/>
   <frame tileid="147" duration="250"/>
  </animation>
 </tile>
 <tile id="148">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="158">
  <animation>
   <frame tileid="158" duration="250"/>
   <frame tileid="159" duration="250"/>
   <frame tileid="160" duration="250"/>
   <frame tileid="161" duration="250"/>
   <frame tileid="162" duration="250"/>
   <frame tileid="163" duration="250"/>
   <frame tileid="164" duration="250"/>
  </animation>
 </tile>
 <tile id="165">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="175">
  <animation>
   <frame tileid="175" duration="250"/>
   <frame tileid="176" duration="250"/>
   <frame tileid="177" duration="250"/>
   <frame tileid="178" duration="250"/>
   <frame tileid="179" duration="250"/>
   <frame tileid="180" duration="250"/>
   <frame tileid="181" duration="250"/>
  </animation>
 </tile>
 <tile id="185">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="192">
  <animation>
   <frame tileid="192" duration="250"/>
   <frame tileid="193" duration="250"/>
   <frame tileid="194" duration="250"/>
   <frame tileid="195" duration="250"/>
   <frame tileid="196" duration="250"/>
   <frame tileid="197" duration="250"/>
   <frame tileid="198" duration="250"/>
  </animation>
 </tile>
 <tile id="203">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="209">
  <animation>
   <frame tileid="209" duration="250"/>
   <frame tileid="210" duration="250"/>
   <frame tileid="211" duration="250"/>
   <frame tileid="212" duration="250"/>
   <frame tileid="213" duration="250"/>
   <frame tileid="214" duration="250"/>
   <frame tileid="215" duration="250"/>
  </animation>
 </tile>
 <tile id="226">
  <animation>
   <frame tileid="226" duration="250"/>
   <frame tileid="227" duration="250"/>
   <frame tileid="228" duration="250"/>
   <frame tileid="229" duration="250"/>
   <frame tileid="230" duration="250"/>
   <frame tileid="231" duration="250"/>
   <frame tileid="232" duration="250"/>
  </animation>
 </tile>
 <tile id="243">
  <animation>
   <frame tileid="243" duration="250"/>
   <frame tileid="244" duration="250"/>
   <frame tileid="245" duration="250"/>
   <frame tileid="246" duration="250"/>
   <frame tileid="247" duration="250"/>
   <frame tileid="248" duration="250"/>
   <frame tileid="249" duration="250"/>
  </animation>
 </tile>
 <tile id="260">
  <animation>
   <frame tileid="260" duration="250"/>
   <frame tileid="261" duration="250"/>
   <frame tileid="262" duration="250"/>
   <frame tileid="263" duration="250"/>
   <frame tileid="264" duration="250"/>
   <frame tileid="265" duration="250"/>
   <frame tileid="266" duration="250"/>
  </animation>
 </tile>
 <tile id="300">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="301">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="302">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="334">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="335">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="336">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="339">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="340">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="341">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="342">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="343">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="344">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="345">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="346">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="347">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="348">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="349">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="350">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="351">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="352">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="353">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="354">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="355">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="373">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="423">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="424">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="440">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="441">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="458">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="475">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
</tileset>
