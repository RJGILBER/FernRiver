<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Spring_zFRBuildings" tilewidth="16" tileheight="16" tilecount="4240" columns="40">
 <image source="Spring_zFRBuildings.png" width="640" height="1696"/>
 <tile id="2116">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="2638">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="2800">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3040">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3041">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3042">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3043">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3044">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3045">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3046">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3047">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3049">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="3080">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3081">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3082">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3083">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3084">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3085">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3086">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3087">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3120">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3121">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3122">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3123">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3124">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3125">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3126">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3127">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3160">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3161">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3162">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3163">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3164">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3165">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3166">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3167">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3200">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3201">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3202">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3203">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3204">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3205">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3206">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3207">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3240">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3241">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3242">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3243">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3244">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3245">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3246">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3247">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3750">
  <animation>
   <frame tileid="3750" duration="100"/>
   <frame tileid="3751" duration="100"/>
  </animation>
 </tile>
</tileset>
