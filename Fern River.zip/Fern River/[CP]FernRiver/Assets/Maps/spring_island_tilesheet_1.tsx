<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="spring_island_tilesheet_1" tilewidth="16" tileheight="16" tilecount="1280" columns="32">
 <image source="spring_island_tilesheet_1.png" width="512" height="640"/>
 <tile id="0">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="135">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="160">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="161">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="162">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="163">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="164">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="165">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="166">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="167">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="168">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="192">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="193">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="197">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="198">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="199">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="200">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="224">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="225">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="229">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="230">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="231">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="232">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="234">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="235">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="236">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="256">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="257">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="261">
  <animation>
   <frame tileid="261" duration="250"/>
   <frame tileid="262" duration="250"/>
   <frame tileid="263" duration="250"/>
   <frame tileid="264" duration="250"/>
   <frame tileid="265" duration="250"/>
   <frame tileid="266" duration="250"/>
   <frame tileid="267" duration="250"/>
  </animation>
 </tile>
 <tile id="268">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="288">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="289">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="293">
  <animation>
   <frame tileid="293" duration="250"/>
   <frame tileid="294" duration="250"/>
   <frame tileid="295" duration="250"/>
   <frame tileid="296" duration="250"/>
   <frame tileid="297" duration="250"/>
   <frame tileid="298" duration="250"/>
   <frame tileid="299" duration="250"/>
  </animation>
 </tile>
 <tile id="300">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="320">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="321">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="325">
  <animation>
   <frame tileid="325" duration="250"/>
   <frame tileid="326" duration="250"/>
   <frame tileid="327" duration="250"/>
   <frame tileid="328" duration="250"/>
   <frame tileid="329" duration="250"/>
   <frame tileid="330" duration="250"/>
   <frame tileid="331" duration="250"/>
  </animation>
 </tile>
 <tile id="335">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="357">
  <animation>
   <frame tileid="357" duration="250"/>
   <frame tileid="358" duration="250"/>
   <frame tileid="359" duration="250"/>
   <frame tileid="360" duration="250"/>
   <frame tileid="361" duration="250"/>
   <frame tileid="362" duration="250"/>
   <frame tileid="363" duration="250"/>
  </animation>
 </tile>
 <tile id="368">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="389">
  <animation>
   <frame tileid="389" duration="250"/>
   <frame tileid="390" duration="250"/>
   <frame tileid="391" duration="250"/>
   <frame tileid="392" duration="250"/>
   <frame tileid="393" duration="250"/>
   <frame tileid="394" duration="250"/>
   <frame tileid="395" duration="250"/>
  </animation>
 </tile>
 <tile id="421">
  <animation>
   <frame tileid="421" duration="250"/>
   <frame tileid="422" duration="250"/>
   <frame tileid="423" duration="250"/>
   <frame tileid="424" duration="250"/>
   <frame tileid="425" duration="250"/>
   <frame tileid="426" duration="250"/>
   <frame tileid="427" duration="250"/>
  </animation>
 </tile>
 <tile id="453">
  <animation>
   <frame tileid="453" duration="250"/>
   <frame tileid="454" duration="250"/>
   <frame tileid="455" duration="250"/>
   <frame tileid="456" duration="250"/>
   <frame tileid="457" duration="250"/>
   <frame tileid="458" duration="250"/>
   <frame tileid="459" duration="250"/>
  </animation>
 </tile>
 <tile id="485">
  <animation>
   <frame tileid="485" duration="250"/>
   <frame tileid="486" duration="250"/>
   <frame tileid="487" duration="250"/>
   <frame tileid="488" duration="250"/>
   <frame tileid="489" duration="250"/>
   <frame tileid="490" duration="250"/>
   <frame tileid="491" duration="250"/>
  </animation>
 </tile>
 <tile id="588">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="589">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="590">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="591">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="592">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="593">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="619">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="620">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="621">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="624">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="625">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="626">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="651">
  <animation>
   <frame tileid="651" duration="250"/>
   <frame tileid="652" duration="250"/>
   <frame tileid="653" duration="250"/>
   <frame tileid="654" duration="250"/>
   <frame tileid="655" duration="250"/>
   <frame tileid="656" duration="250"/>
   <frame tileid="657" duration="250"/>
  </animation>
 </tile>
 <tile id="658">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="659">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="683">
  <animation>
   <frame tileid="683" duration="250"/>
   <frame tileid="684" duration="250"/>
   <frame tileid="685" duration="250"/>
   <frame tileid="686" duration="250"/>
   <frame tileid="687" duration="250"/>
   <frame tileid="688" duration="250"/>
   <frame tileid="689" duration="250"/>
  </animation>
 </tile>
 <tile id="690">
  <properties>
   <property name="Type" value="Water"/>
  </properties>
 </tile>
 <tile id="715">
  <animation>
   <frame tileid="715" duration="250"/>
   <frame tileid="716" duration="250"/>
   <frame tileid="717" duration="250"/>
   <frame tileid="718" duration="250"/>
   <frame tileid="719" duration="250"/>
   <frame tileid="720" duration="250"/>
   <frame tileid="721" duration="250"/>
  </animation>
 </tile>
 <tile id="744">
  <animation>
   <frame tileid="744" duration="250"/>
   <frame tileid="745" duration="250"/>
   <frame tileid="746" duration="250"/>
   <frame tileid="745" duration="250"/>
  </animation>
 </tile>
 <tile id="747">
  <animation>
   <frame tileid="747" duration="250"/>
   <frame tileid="748" duration="250"/>
   <frame tileid="749" duration="250"/>
   <frame tileid="750" duration="250"/>
   <frame tileid="751" duration="250"/>
   <frame tileid="752" duration="250"/>
   <frame tileid="753" duration="250"/>
  </animation>
 </tile>
 <tile id="776">
  <animation>
   <frame tileid="776" duration="250"/>
   <frame tileid="777" duration="250"/>
   <frame tileid="778" duration="250"/>
   <frame tileid="777" duration="250"/>
  </animation>
 </tile>
</tileset>
