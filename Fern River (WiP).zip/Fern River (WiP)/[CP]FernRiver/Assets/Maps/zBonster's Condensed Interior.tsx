<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="zBonster's Condensed Interior" tilewidth="16" tileheight="16" tilecount="3300" columns="30">
 <image source="zBonster's Condensed Interior.png" width="480" height="1760"/>
 <tile id="691">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="930">
  <properties>
   <property name="Type" value="Water"/>
   <property name="Water" value="T"/>
  </properties>
  <animation>
   <frame tileid="930" duration="100"/>
   <frame tileid="931" duration="100"/>
   <frame tileid="932" duration="100"/>
   <frame tileid="933" duration="100"/>
   <frame tileid="934" duration="100"/>
   <frame tileid="935" duration="100"/>
   <frame tileid="936" duration="100"/>
   <frame tileid="937" duration="100"/>
   <frame tileid="938" duration="100"/>
   <frame tileid="939" duration="100"/>
   <frame tileid="960" duration="100"/>
   <frame tileid="961" duration="100"/>
   <frame tileid="962" duration="100"/>
   <frame tileid="963" duration="100"/>
   <frame tileid="964" duration="100"/>
   <frame tileid="965" duration="100"/>
   <frame tileid="966" duration="100"/>
  </animation>
 </tile>
 <tile id="1907">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="1908">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="1909">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="1913">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="1914">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="1915">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2027">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2028">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2029">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2033">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2034">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2035">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2147">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2148">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2149">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2153">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2154">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2155">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2263">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2264">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2267">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
 <tile id="2268">
  <properties>
   <property name="Passable" value="T"/>
  </properties>
 </tile>
</tileset>
